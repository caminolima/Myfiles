import pyshark
import time
import keyboard

#Definimos el constructor
class sniffertshark:

    def __init__(self):
        self.capture = None
        #Ahora creamos otro atributo de instancia que hace referencia a los paquetes capturados
        #que guardaremos en captured package
        self.captured_packets = []

    #Primero haceos una funcion que capture los paquetes
    # A esta funcion le pasaremos como interface "any" y le pasamos un display filter
    # que utiliza filtros bpf. En principio dejamos los filtros a "" vacios
    def inicio_captura(self, interface="any",display_filter = ""):
        #Definimos nuestro objeto capture con Livecapture, ya que es una
        #captura en tiempo real
        self.capture=pyshark.LiveCapture(
            interface=interface,
            display_filter=display_filter,
            #use_json=True,
            #include_raw=True
        )
        #include_raw=True esto es para que conserve el RAW de los paquetes
        #Iniciamos la captura

        #Utilizaremos el objeto self.captured_packets ya que es una lista
        #y luego será mas facil recorrer esta lista que el propio objeto capture
        #ya que al guardar en raw no es un objeto iterable que se pueda recorrer bien

        try:
            print("Captura de paquetes iniciada, pulse ctrl+c para detenerla")
            #Para que a medida que recibamos los paquetes se puedan ir guardando en la lista
            #self.captured_packets utilizamos
            for packet in self.capture.sniff_continuously():
                #Esto va a ir capturando el trafico de red y metiendolo en la variable packet
                #Y ahora como tenemos la lista captured_packets pues lo vamos aladiendo a la misma
                #ya que como vimos antes manejarse por una lista cuando utilizamos RAW es más comodo
                self.captured_packets.append(packet)
                

        except (KeyboardInterrupt,EOFError):

            #con esto si el usuario pulsa ctrl+c o si hay un end of file, propio a veces de pyshark
            print("Captura cortada por el usuario o por End of file")
            #Ahora imprimimos el numero de elementos de la lista captured_packets
            #La función len devuelve el número de valores de un elemento iterable en Python
            print("Numero de paquetes capturados", len(self.captured_packets))

    #Ahora hacemos una funcion para ir imprimiendo los paquetes por pantalla
    #Utilizando filtros de visualizacion por ejemplo para ver posibles ataques a nuestro PC
    #le pasamos un conjunto de paquetes que por defecto sera NULL = None
    def visualizar_paquetes(self, packets=None):
        #Si no le pasan paquetes entonces le didremos que los paquetes
        #sean los que estan en la lista de los paquetes capturados,la cual se carga en"inicio_captura"
        if packets is None:
            packets=self.captured_packets
        #Ahora recorremos el objeto packets invocando al método sho
        for packet in packets:
            print(packet)
            #le metemos un separador de 20 guiones
            print("___"*20)

    #Si queremos filtrar la lista por protocolo
    def filtrado_protocolo(self,protocol):
        filtered_packets = [pkt for pkt in self.captured_packets if protocol in pkt]
        return filtered_packets
