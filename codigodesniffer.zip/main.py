from Control_de_snifferTshark import sniffertshark


if __name__ == "__main__":
    #Definimos una variable sniffer la cual es la invocacion al metodo sniffertshark()
    sniffer = sniffertshark()
    #Capturamos los sniffers hasta pulsar ctrl+c
    sniffer.inicio_captura()

    #filtramos por protocolo http
    packets = sniffer.filtrado_protocolo('http')

    #visualizamos los paquetes capturados
    sniffer.visualizar_paquetes(packets)
